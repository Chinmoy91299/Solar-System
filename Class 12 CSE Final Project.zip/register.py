from tkinter import *
import os as o
from time import strftime
import mysql.connector
from datetime import datetime
root4 = Tk()
root4.geometry('500x500')
root4.title("Registration Form")
#database---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def SaveData():
    now = datetime.now()
    current_time =now.strftime("%Y/%m/%d %H:%M:%S")
    name=entry_1.get()
    email=entry_2.get()
    gender=entry_3.get()
    age=entry_4.get()
    mydb=mysql.connector .connect(host="localhost",user="root",passwd="chinmoy123",   auth_plugin='mysql_native_password',database="exploring_the_solar_system")
    mycursor=mydb.cursor()

    sql="INSERT INTO Register(Name,Email,Gender,Age,Time) VALUES(%s,%s,%s,%s,%s)"
    val=(name,email,gender,age,current_time)

    mycursor.execute(sql,val)
    mydb.commit()
#NewWindow----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    root4.destroy()
    root5=Tk() 
    root5.geometry("700x150")
    root5.config(background="lemon chiffon")
    root5.title("Congratulations!!!")
    Label(root5,width=45,height=6,font=('Times',15),bg='lemon chiffon',fg="black",justify=LEFT,text="Congratulation you have succesfully registered.\nClick the button for a small space tour.").grid(row=0,column=0)
    Button(root5,text='This way',height=3,width=15,bg="OrangeRed2",command=maincd).place(x=580,y=80)
#Register------------------------------------------------------------------------------------------------------------------------------------------------------
root4.title("Registration Form")
label_0 = Label(root4, text="Registration form",width=20,font=("bold", 20))
label_0.place(x=90,y=53)
label_1 = Label(root4, text="Full Name",width=20,font=("bold", 10))
label_1.place(x=80,y=130)
entry_1 = Entry(root4)
entry_1.place(x=240,y=130)
label_2 = Label(root4,text="Email",width=20,font=("bold", 10))
label_2.place(x=68,y=180)
entry_2 = Entry(root4)
entry_2.place(x=240,y=180)
label_3 = Label(root4, text="Gender",width=20,font=("bold", 10))
label_3.place(x=70,y=230)
entry_3= Entry(root4)
entry_3.place(x=240,y=230)
label_4 = Label(root4, text="Age:",width=20,font=("bold", 10))
label_4.place(x=70,y=280)
entry_4 = Entry(root4)
entry_4.place(x=240,y=280)
Button(root4,text='Exit',width=20,bg='brown',fg='white',command=quit).place(x=280,y=380)
Button(root4,text='Submit',width=20,bg='brown',fg='white',command=SaveData).place(x=80,y=380)
#TIME-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def time(): 
    string = strftime('%H:%M:%S %p') 
    lbl.config(text = string) 
    lbl.after(1000, time)
lbl = Label(root4, font = ('calibri', 25, 'bold'), background = 'white', foreground = 'black')
lbl.pack(anchor = 'center') 
time()
#MainCODE------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def maincd():
    o.system('start test.py')
root4.mainloop()



   
   
             

import mysql.connector 
mydb=mysql.connector .connect(host="localhost",user="root",passwd="chinmoy123",   auth_plugin='mysql_native_password',database="exploring_the_solar_system")
mycursor=mydb.cursor()
mycursor.execute("create table Register(Name Varchar(30),Email Varchar(30),Gender Varchar(20),Age INT(10),Time timestamp)")
